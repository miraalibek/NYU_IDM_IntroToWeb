// create a function for closing button

// create a function for loading the image with a parameter that sets file path

// createElement var img =

// apprendChild(img) to modal

// style the image (style.src, style.position with left/right/transform, style.width, style.maxHeight)
