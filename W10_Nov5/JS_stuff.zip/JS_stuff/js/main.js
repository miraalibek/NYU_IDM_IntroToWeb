function msg() {  
       window.alert("Message from External JS file"); 
} 


